package com.example.order.service;

import com.example.order.domain.Order;
import com.example.order.domain.OrderLine;
import org.springframework.stereotype.Service;

@Service
public class OrderService {

    public Order calculateOrderTotal(Order order) {

        order.getOrderLines().forEach(line -> {
            line.setLineTotal(calculateLineTotal(line));
        });
        Double totalCreated = order.getOrderLines().stream()
                .filter(orderLine -> orderLine.getLineStatus().equals("CREATED"))
                .mapToDouble(line -> line.getLineTotal()).sum();
        Double totalCancel = order.getOrderLines().stream()
                .filter(orderLine -> orderLine.getLineStatus().equals("CANCELLED"))
                .mapToDouble(line -> line.getLineTotal()).sum();
        Double totalReturn = order.getOrderLines().stream()
                .filter(orderLine -> orderLine.getLineStatus().equals("RETURNED"))
                .mapToDouble(line -> line.getLineTotal()).sum();
        order.setOrderTotal(totalCreated - (totalCancel + totalReturn));

        return order;
    }

    private Double calculateLineTotal(OrderLine line) {
        return line.getLineTotalWithoutTax()
                + line.getLineCharges().stream().mapToDouble(lineC -> lineC.getChargeAmount()).sum()
                + line.getTaxes().stream().mapToDouble(tax -> tax.getTaxAmount()).sum();
    }
}
