package com.example.order.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class OrderLine {

    @JsonProperty("OrderLineNumber")
    private Integer orderLineNumber;

    @JsonProperty("LineStatus")
    private String lineStatus;

    @JsonProperty("LineTotalWithoutTax")
    private Double lineTotalWithoutTax;

    @JsonProperty("LineTotal")
    private Double lineTotal;

    @JsonProperty("LineCharges")
    private List<LineCharge> lineCharges;

    @JsonProperty("Taxes")
    private List<Tax> taxes;

    public Integer getOrderLineNumber() {
        return orderLineNumber;
    }

    public void setOrderLineNumber(Integer orderLineNumber) {
        this.orderLineNumber = orderLineNumber;
    }

    public String getLineStatus() {
        return lineStatus;
    }

    public void setLineStatus(String lineStatus) {
        this.lineStatus = lineStatus;
    }

    public Double getLineTotalWithoutTax() {
        return lineTotalWithoutTax;
    }

    public void setLineTotalWithoutTax(Double lineTotalWithoutTax) {
        this.lineTotalWithoutTax = lineTotalWithoutTax;
    }

    public Double getLineTotal() {
        return lineTotal;
    }

    public void setLineTotal(Double lineTotal) {
        this.lineTotal = lineTotal;
    }

    public List<LineCharge> getLineCharges() {
        return lineCharges;
    }

    public void setLineCharges(List<LineCharge> lineCharges) {
        this.lineCharges = lineCharges;
    }

    public List<Tax> getTaxes() {
        return taxes;
    }

    public void setTaxes(List<Tax> taxes) {
        this.taxes = taxes;
    }
}
