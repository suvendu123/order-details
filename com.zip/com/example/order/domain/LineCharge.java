package com.example.order.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LineCharge {

   @JsonProperty("ChargeType")
   private String  chargeType;

   @JsonProperty("ChargeAmount")
   private Double  chargeAmount;

   public String getChargeType() {
      return chargeType;
   }

   public void setChargeType(String chargeType) {
      this.chargeType = chargeType;
   }

   public Double getChargeAmount() {
      return chargeAmount;
   }

   public void setChargeAmount(Double chargeAmount) {
      this.chargeAmount = chargeAmount;
   }
}
