package com.example.order.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Tax {

    @JsonProperty("TaxType")
    private String taxType;

    @JsonProperty("TaxAmount")
    private Double  taxAmount;

    public String getTaxType() {
        return taxType;
    }

    public void setTaxType(String taxType) {
        this.taxType = taxType;
    }

    public Double getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(Double taxAmount) {
        this.taxAmount = taxAmount;
    }
}
