package com.example.order.controller;

import com.example.order.domain.Order;
import com.example.order.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderController {

    @Autowired
    private OrderService service;

    @PostMapping(value = "/order")
    public ResponseEntity<Order> calculateOrderTotal(@RequestBody Order order) {
        return new ResponseEntity<>(service.calculateOrderTotal(order), HttpStatus.OK);
    }
}
